$(document).ready(function(){
	console.log('я на главной странице');
})